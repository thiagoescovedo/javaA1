package Controle;

public class LavarCarro {
    
    private int CodigoLavagem=0;
    private String TipoLavagem;
    private double ValorLavagem;
    private double NotaServico;
    
    private int ContCodigo;
    private double Total=0;
    private double Media=0;
    
    public boolean AdicionarServico(String TipoLavagem,String ValorLavagem,String NotaServico){
        this.TipoLavagem=TipoLavagem;
        try{
            this.ValorLavagem=Double.parseDouble(ValorLavagem);
            this.NotaServico=Double.parseDouble(NotaServico);
            return true;
        }
        catch(Exception e){
            return false;
        }
        
    }
    
    public Object[] Linha(){
        CodigoLavagem++;
        Total=Total+ValorLavagem;
        Media=Total/CodigoLavagem;
        
        return new Object[]{CodigoLavagem,TipoLavagem,ValorLavagem,NotaServico};
    }
    
    public double getTotal(){
        return Total;
    }
    
    public double getMedia(){
        return Media;
    }
    
}

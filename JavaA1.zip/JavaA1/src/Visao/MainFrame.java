package Visao;

import Controle.LavarCarro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MainFrame extends JFrame implements ActionListener{
    
    private Controle.LavarCarro lavarCarro = new Controle.LavarCarro();
    
    private JTable tabela;
    private DefaultTableModel modelo;
    private JScrollPane barra;
    
    private JLabel LabelTipo,LabelValor,LabelNota;
    private JTextField TextTipo,TextValor,TextNota;
    private JButton atendimento;
    
    private JLabel Total,Media;
    
    public MainFrame(){
        super("Lavar Carro");
        
        this.setBounds(10, 10, 800, 500);
        this.setLayout(null);
        
        tabela = new JTable();
        
        modelo =(DefaultTableModel) tabela.getModel();
        modelo.setNumRows(0);
        modelo.addColumn("CodigoLavagem");
        modelo.addColumn("TipoLavagem");
        modelo.addColumn("ValorLavagem");
        modelo.addColumn("NotaServico");
        
        barra = new JScrollPane(tabela);
        barra.setBounds(5,5,500,450);
        
        LabelTipo = new JLabel("Tipo:");
        LabelTipo.setBounds(520,5,150,20);
        
        TextTipo = new JTextField();
        TextTipo.setBounds(520,25,250,20);
        
        LabelValor = new JLabel("Valor");
        LabelValor.setBounds(520,55,150,20);
        
        TextValor = new JTextField();
        TextValor.setBounds(520,75,150,20);
        
        LabelNota = new JLabel("Nota");
        LabelNota.setBounds(520,105,150,20);
        
        TextNota = new JTextField();
        TextNota.setBounds(520,125,150,20);
        
        atendimento = new JButton("Efetuar Atendimento");
        atendimento.addActionListener(this);
        atendimento.setBounds(520,180,250,20);
        
        Total = new JLabel("Total: 0");
        Total.setBounds(520,400,150,20);
        
        Media = new JLabel("Media: 0");
        Media.setBounds(520,430,150,20);
        
        this.add(barra);
        this.add(LabelTipo);
        this.add(TextTipo);
        this.add(LabelValor);
        this.add(TextValor);
        this.add(LabelNota);
        this.add(TextNota);       
        this.add(atendimento);
        this.add(Total);
        this.add(Media);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == atendimento){
            
            boolean isOK = lavarCarro.AdicionarServico( TextTipo.getText(),TextValor.getText(),TextNota.getText() );
            
            if(isOK){
                modelo.addRow(lavarCarro.Linha());
                TextTipo.setText("");
                TextNota.setText("");
                TextValor.setText("");
                
                Total.setText("Total: "+lavarCarro.getTotal());
                Media.setText("Media: "+lavarCarro.getMedia());
            }
        }
    }
    
}
